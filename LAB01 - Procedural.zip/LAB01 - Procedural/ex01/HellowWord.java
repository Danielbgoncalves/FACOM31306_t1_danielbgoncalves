public class Main{

    public static void main(String[] args){
        System.out.println("Daniel Borges GOnçalves, 12311bcc005");
    }
}