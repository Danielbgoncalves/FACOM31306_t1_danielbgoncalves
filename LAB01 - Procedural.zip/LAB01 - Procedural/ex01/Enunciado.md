# Ex01 

Faça um programa 'Hello World' em Java, que mostre também o seu nome e número de matrícula

Para isso, abra um editor de texto qualquer (e não uma IDE java) e programe no arquivo HelloWorld.java

Compile usando javac e rode usando java, como mostrado abaixo

> javac HelloWorld.java
> dir (para vc ver o arquivo .class que foi criado)
> java <nome do arquivo .class criado>