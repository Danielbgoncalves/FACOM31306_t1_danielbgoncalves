# Ex02 

Faça um programa em Java equivalente ao exemplo04.c (pasta samples/TADProduto)

Utilize a IDE InteliJ para programar