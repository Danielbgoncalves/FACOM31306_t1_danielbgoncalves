public class Eleicao {

}
